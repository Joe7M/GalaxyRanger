t = 0:100:12000;
color= linspace(0,255,length(t));

XA =  640;  %639;
XB =  -0.05;     %-0.0002;
XC =  0;  %0;
XD =  1;      %2;
x = XA + XB*(t - XC).^XD;

YA = 300;
YB = 0;
YC = 0;
YD = 1;
y = YA + YB*(t - YC).^YD;



figure(1)
subplot(1,2,1)
  scatter(x,y,[],color)
  colormap(jet(255));
  xlabel("x")
  ylabel("y") 
subplot(1,2,2)
 scatter(x,y,[],color)
 colormap(jet(255));
 ylim([0,480])
 xlim([0,640]);
 xlabel("x")
 ylabel("y")
  

disp(x(1))
disp(y(1))