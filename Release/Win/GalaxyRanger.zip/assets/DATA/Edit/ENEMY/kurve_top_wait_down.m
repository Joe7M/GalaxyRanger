t = 0:500:6000;
color= linspace(0,255,length(t));

XA =  660;
XB =  -0.11;
XC =  0;
XD =  1;
x = XA + XB*(t - XC).^XD;

YA = 200;
YB = 0.000000008;
YC = 3000;
YD = 3;
y = YA + YB*(t - YC).^YD;



figure(1)
subplot(2,2,1)
  plot(t,x);
  ylim([0,640])
  ylabel("x")
  xlabel("t")
subplot(2,2,2)
  plot(t,y)
  set(gca,'Ydir','reverse')
  ylim([0,480])
  ylabel("y")
  xlabel("t")  
subplot(2,2,3)
  scatter(x,y,[],color)
  set(gca,'Ydir','reverse')
  colormap(jet(255));
  xlabel("x")
  ylabel("y") 
subplot(2,2,4)
 scatter(x,y,[],color)
 set(gca,'Ydir','reverse')
 colormap(jet(255));
  axis image
 ylim([0,480])
 xlim([0,640]);
 xlabel("x")
 ylabel("y")


disp(x(1))
disp(y(1))